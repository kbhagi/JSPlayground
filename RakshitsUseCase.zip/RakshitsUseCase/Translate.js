var AWS = require('aws-sdk');
var translate = new AWS.Translate();


exports.handler = (event, context, callback) => {

    var params = {
        Text: event.inputText,
        SourceLanguageCode: event.SourceLanguageCode,
        TargetLanguageCode: event.TargetLanguageCode
    };
    translate.config.update({
        accessKeyId: 'AKIATN7MS7Z2FXQSD7MT',
        secretAccessKey: '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',
        region:'us-west-1'
    });

    translate.translateText(params, function(err, data) {
        if (err) {
            console.log(err, err.stack);
        }
        if (data) {
            console.log(data.TranslatedText);
        }
    });
}; 